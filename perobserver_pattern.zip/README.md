# Perobserver Pattern

Perobserver is a design pattern where an observer automatically persists
the state of an observed object whenever its state changes.

State Change → Event → Perobserver → Persist State
